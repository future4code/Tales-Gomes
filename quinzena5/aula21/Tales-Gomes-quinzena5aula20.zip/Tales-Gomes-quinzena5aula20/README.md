Alunos(as), sejam bem-vindos(as)!

Esse repositório vai acompanhar vocês até o final do curso, para mantermos a organização, sugerimos que vocês sigam a seguinte estrutura:

```
.
├── semana-0
│   ├── aula1
│   ├── aula2
│   └── projeto-nome
|
├── semana-1
│   ├── aula3
│   ├── aula4
│   ├── aula5
│   ├── aula6
│   └── projeto-nome
|
├── semana-2
│   ├── aula7
│   ├── aula8
│   ├── aula9
│   ├── aula10
│   └── projeto-nome
|
├── semana-3
│   ├── aula11
│   ├── aula12
│   ├── aula13
│   ├── aula14
│   └── projeto-nome
|
├── semana-4
│   ├── aula15
│   ├── aula16
│   ├── aula17
│   ├── aula18
│   └── projeto-nome
|
```

Uma pasta para cada semana, dentro delas uma pasta para cada dia de aula e por fim uma pasta para o projeto da semana.
